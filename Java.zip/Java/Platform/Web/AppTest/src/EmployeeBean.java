package classic.web.app;

import java.sql.*;
import java.util.*;

public class EmployeeBean implements java.io.Serializable {

	private int id;
	private String password;
	private int DeptNo;

	public final int getId() { return id; }
	public final void setId(int value) { id = value; }

	public final String getPassword() { return password; }
	public final void setPassword(String value) { password = value; }

	public final int getDeptNo() { return DeptNo; }
	public final void setDeptNo(int value) { DeptNo = value; }

	public boolean authenticate() throws SQLException {
		try(var con = DB.connect()){
			var pstmt = con.prepareStatement("select count(id) from Admin where id=? and password=?");
			pstmt.setInt(1, id);
			pstmt.setString(2, password);
			var rs = pstmt.executeQuery();
			rs.next();
			int count = rs.getInt(1);
			rs.close();
			pstmt.close();
			if(count == 1)
				return true;
			id =0; 
			password = null;
			return false;
		}
	}

	public boolean search() throws SQLException {
		try(var con = DB.connect()){
			var pstmt = con.prepareStatement("select count(DeptNo) from department where DeptNo=? ");
			pstmt.setInt(1, DeptNo);
			var rs = pstmt.executeQuery();
			rs.next();
			int count = rs.getInt(1);
			rs.close();
			pstmt.close();
			if(count == 1)
				return true;
			/*id =0; 
			password = null;
		*/	return false;
		}
	}
	public List<departmentEntry> getdepartment() throws SQLException {
		var dept = new ArrayList<departmentEntry>();
		try(var con = DB.connect()){
			var pstmt = con.prepareStatement("select DeptNo, DeptName, Location from department ");
		//	pstmt.setInt(1, id);
			var rs = pstmt.executeQuery();
			while(rs.next())
				dept.add(new departmentEntry(rs));
			rs.close();
			pstmt.close();
		}
		return dept;
	}

	public List<employeeEntry> getemployee() throws SQLException {
		var emp = new ArrayList<employeeEntry>();
		try(var con = DB.connect()){
			var pstmt = con.prepareStatement("select EmpName, Age, Salary from employee ");
		//	pstmt.setInt(1, id);
			var rs = pstmt.executeQuery();
			while(rs.next())
				emp.add(new employeeEntry(rs));
			rs.close();
			pstmt.close();
		}
		return emp;
	}

	public static class departmentEntry {
		
		private int DepartmentNo ;
		private String DepartmentName;
		private String Location;

		departmentEntry(ResultSet rs) throws SQLException {
			DepartmentNo = rs.getInt("DeptNo");
			DepartmentName = rs.getString("DeptName");
			Location = rs.getString("Location");
		}

		public final int getDepartmentNo() { return DepartmentNo; }

		public final String getDepartmentName() { return DepartmentName; }

		public final String getLocation() { return Location; }
	}
	

	public static class employeeEntry {
		
		private String EmployeeName ;
		private int Age;
		private int Salary;

		employeeEntry(ResultSet rs) throws SQLException {
			EmployeeName = rs.getString("EmpName");
			Age = rs.getInt("Age");
			Salary = rs.getInt("Salary");
		}

		public final String getEmployeeName() { return EmployeeName; }

		public final int getAge() { return Age; }

		public final int getSalary() { return Salary; }
	}
}

