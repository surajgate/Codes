class Deviation {
	public double value;
}

