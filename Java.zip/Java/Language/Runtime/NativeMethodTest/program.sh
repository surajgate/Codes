java -Djava.library.path=. Program $*

