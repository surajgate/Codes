namespace ModernWebApp.Resources;

public class OrderResource
{
    public int OrderNo { get; set; }

    public string OrderDate { get; set; }

    public string CustomerId { get; set; }

    public int ProductNo { get; set; }

    public int Quantity { get; set; }
}
