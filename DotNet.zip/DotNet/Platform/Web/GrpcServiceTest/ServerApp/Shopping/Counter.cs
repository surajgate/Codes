namespace ServerApp.Shopping;

public class Counter
{
    public string Id { get; set; }

    public int SeedValue { get; set; }

    public int CurrentValue { get; set; }
}
